<div class="row-content am-cf">
    <div class="widget am-cf">
        <div class="widget-body">
            <div class="tpl-page-state am-margin-top-xl">
                <div class="tpl-page-state-title am-text-center"><?= $setting['store']['values']['name'] ?></div>
                <div class="tpl-error-title-info">Welcome To YoShop System</div>
                <div class="tpl-page-state-content tpl-error-content">
                    <p>商城管理后台</p>
                </div>
            </div>
        </div>
    </div>
</div>
